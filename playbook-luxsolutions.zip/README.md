# Playbook LUXSolutions

Treinamento comercial da LUXSolutions em nove módulos sequenciais, numa única página HTML,
sem dependências e sem build.

## Módulos

| # | Módulo | O que traz |
|---|---|---|
| 01 | O que é a LUXSolutions | Problema, entrega, as seis qualidades e a tradução de funcionalidade em valor |
| 02 | Escopo e formas de entrada | Os sistemas e os quatro caminhos de entrada comercial |
| 03 | Qualificação | Filtro de escala e a calculadora do Índice de Aderência |
| 04 | Cenários de cliente | Onze dossiês de segmento e onde procurar o dinheiro na conta |
| 05 | Demonstração | Os três movimentos, os três fluxos e a divisão da reunião em 20/30/10 |
| 06 | Objeções | Doze objeções com o que está por trás, três movimentos e exercício |
| 07 | Funil e checklists | Critérios de avanço, preparação, sinais de alerta e registro |
| 08 | Certificação | Onze questões com correção comentada, corte em 80% |
| 09 | Glossário | Os termos que aparecem nos módulos e nas conversas com cliente |

## Como abrir

Abra `index.html` no navegador. Não precisa servidor.

Para publicar em GitHub Pages: Settings › Pages › Source: `main` / raiz. A página fica em
`https://<usuario>.github.io/<repo>/`.

## Detalhes técnicos

- Página única, sem framework, sem dependência externa além da fonte Montserrat pelo Google Fonts.
- Tema claro e escuro, seguindo a preferência do sistema, com alternância manual.
- Progresso dos módulos e checklists salvos no `localStorage` do próprio navegador.
- Texto justificado com hifenização em português: `hyphens:auto` mais um hifenizador próprio
  que insere pontos de quebra por regra de sílaba, com remoção dos hifens invisíveis ao copiar.
- Alternativas dos exercícios embaralhadas a cada exibição.

O treinador livre das objeções, que pede avaliação escrita a um modelo, só funciona dentro do
Claude. Fora dele o bloco simplesmente não aparece; o resto da página funciona igual.

## Identidade

Fonte Montserrat e paleta Lux 2026: `#0B2A3D`, `#1F4E6B`, `#2F6F8F`, `#4F7F99`, `#0F3834`,
`#4E7D5B`, `#8BC34A`, `#E6ECEF`, `#FBFFEF`, `#6B7C88`.

## Pendências de conteúdo

Estão registradas fora deste repositório, no arquivo de pendências internas entregue junto com
o playbook. A principal é a ausência de um modelo de precificação documentado da plataforma.
